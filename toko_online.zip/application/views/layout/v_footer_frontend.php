
</div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
		WEB TOKO ONLINE
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="">Ohsan</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->
<script>
	window.setTimeout(function(){
		$(".alert").fadeTo(500.0).slideUp(500,function(){
			$(this).remove();
		});
	},3000)
</script>


